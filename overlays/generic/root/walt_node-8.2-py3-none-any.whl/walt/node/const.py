SERVER_LOGS_FIFO = "/var/lib/walt/logs.fifo"
